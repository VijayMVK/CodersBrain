import { Component } from '@angular/core';

@Component({
    selector: 'bundle-generator',
    templateUrl: 'bundle-generator.component.html'
})
export class BundleGeneratorComponent {
}