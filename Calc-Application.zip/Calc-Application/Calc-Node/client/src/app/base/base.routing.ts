import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const baseRoutes: Routes = [    
];

export const BaseRouting: ModuleWithProviders = RouterModule.forChild(baseRoutes);
