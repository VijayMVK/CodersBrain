import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const sharedRoutes: Routes = [
    
            
];

export const SharedRouting: ModuleWithProviders = RouterModule.forChild(sharedRoutes);
