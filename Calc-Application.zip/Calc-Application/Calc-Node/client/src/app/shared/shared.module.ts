import { NgModule }      from '@angular/core';
import { SharedRouting } from './shared.routing';

@NgModule({
    imports: [         
        SharedRouting  
    ],    
    declarations: [          
    ]
})
export class SharedModule {
       
}
