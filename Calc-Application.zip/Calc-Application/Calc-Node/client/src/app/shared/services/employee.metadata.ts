﻿export class EmployeeMetadata {
    empNo:number;
    empName: string;
    salary: number;   
    deptNo:number;   
}