import { Component } from '@angular/core';

@Component({
    selector: 'carton',
    templateUrl: 'carton.component.html'
})
export class CartonComponent {
}