import { Component } from '@angular/core';

@Component({
    selector: 'stores-delivery',
    templateUrl: 'stores-delivery.component.html'
})
export class StoresDeliveryComponent {
    value:any="123456"
}