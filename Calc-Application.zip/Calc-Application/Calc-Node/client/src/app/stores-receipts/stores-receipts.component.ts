import { Component } from '@angular/core';

@Component({
    selector: 'stores-receipts',
    templateUrl: 'stores-receipts.component.html'
})
export class StoresReceiptsComponent {
}