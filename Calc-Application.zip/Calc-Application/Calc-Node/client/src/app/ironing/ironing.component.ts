import { Component } from '@angular/core';

@Component({
    selector: 'ironing',
    templateUrl: 'ironing.component.html'
})
export class IroningComponent {
}