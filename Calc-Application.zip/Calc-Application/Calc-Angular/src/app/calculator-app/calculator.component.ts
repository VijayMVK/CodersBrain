import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonService } from '../shared/service/common.service';
import { OperatorModel, InputModel, ResultModel } from './calculator.model';

@Component({
  selector: 'calc',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CalcComponent implements OnInit {
  readonly api = "http://localhost:8000/api/";
  showOverlay: boolean = false;
  resultColor: string = 'lightskyblue';
  result: number = null;
  inputs: InputModel[] = [];
  operators: OperatorModel[] = [];

  constructor(private commonService: CommonService) { }

  ngOnInit() {
    this.getOperators(this.api + 'getOperators');
    this.getInputs(this.api + 'getInputs');
  }

  getOperators(url: string) {
    this.showOverlay = true;
    this.commonService.getData(url).subscribe(
      (data: OperatorModel[]) => { this.operators = data; this.showOverlay = false },
      error => this.showOverlay = false
    )
  }

  getInputs(url: string) {
    this.showOverlay = true;
    this.commonService.getData(url).subscribe(
      (data: InputModel[]) => { this.inputs = data; this.showOverlay = false },
      error => this.showOverlay = false
    )
  }

  isDisable(): boolean {
    const len: number = this.inputs.filter(x => !x.value).length;
    return len ? true : false;
  }

  cal() {
    let expression: string = "";
    this.inputs.map(x => {
      expression = expression + x.value;
    });
    this.getResult(this.api + 'getResult', expression);
  }

  getResult(url: string, expression: string) {
    this.showOverlay = true;
    this.commonService.getResult(url, expression).subscribe(
      (data: ResultModel) => { this.result = data.result; this.resultColor = data.color;this.showOverlay = false },
      error => this.showOverlay = false
    )
  }

}
