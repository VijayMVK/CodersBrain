export interface OperatorModel {
    name: string,
    value: string
}

export interface InputModel {
    type: string,
    value: string
}

export interface ResultModel {
    color: string,
    result: number
}
